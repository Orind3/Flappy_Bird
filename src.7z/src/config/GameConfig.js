var FlippyBird = FlippyBird || {};

FlippyBird.CONTAINER = {
    BACKSKYS:[],
    BACKGROUND:[],
    PIPES:[],
};

let GAMESCORE = 0;